﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MattNode
{
    public partial class DragSpacePanel : UserControl
    {
        protected bool clicked = false;
        protected Point MousePrevPoint;
        protected Panel spacePanel;

        public DragSpacePanel()
        {
        }

        protected void Drag_MouseDown(object sender, MouseEventArgs e)
        {
            clicked = true;
            MousePrevPoint = Cursor.Position;
        }

        protected void Drag_MouseLeave(object sender, EventArgs e)
        {
            clicked = false;
        }

        protected void Drag_MouseUp(object sender, EventArgs e)
        {
            clicked = false;
        }

        protected void Drag_MouseMove(object sender, MouseEventArgs e)
        {
            if (clicked)
            {
                spacePanel.Location = Point.Add(spacePanel.Location, new Size(Point.Subtract(Cursor.Position, new Size(MousePrevPoint))));
                MousePrevPoint = Cursor.Position;
            }
        }
    }
}
